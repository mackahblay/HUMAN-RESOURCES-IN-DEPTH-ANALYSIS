# Melchizedek Ackah-Blay

December 11, 2024

**Human Resources Case**

*load libraries*


```python
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.style as style
style.use('ggplot')
import seaborn as sns

import warnings as w
w.filterwarnings('ignore')
```

*load data*


```python
dataset = pd.read_csv(r'/Users/melki/Desktop/human_resource_data.csv')
```

*show sample data*


```python
dataset.sample(4)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Employee_Name</th>
      <th>EmpID</th>
      <th>MarriedID</th>
      <th>MaritalStatusID</th>
      <th>GenderID</th>
      <th>EmpStatusID</th>
      <th>DeptID</th>
      <th>PerfScoreID</th>
      <th>FromDiversityJobFairID</th>
      <th>Salary</th>
      <th>...</th>
      <th>ManagerName</th>
      <th>ManagerID</th>
      <th>RecruitmentSource</th>
      <th>PerformanceScore</th>
      <th>EngagementSurvey</th>
      <th>EmpSatisfaction</th>
      <th>SpecialProjectsCount</th>
      <th>LastPerformanceReview_Date</th>
      <th>DaysLateLast30</th>
      <th>Absences</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>95</th>
      <td>Forrest, Alex</td>
      <td>10305</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>6</td>
      <td>3</td>
      <td>0</td>
      <td>70187</td>
      <td>...</td>
      <td>Lynn Daneault</td>
      <td>21.0</td>
      <td>Employee Referral</td>
      <td>PIP</td>
      <td>2.00</td>
      <td>5</td>
      <td>0</td>
      <td>1/28/2019</td>
      <td>4</td>
      <td>7</td>
    </tr>
    <tr>
      <th>306</th>
      <td>Woodson, Jason</td>
      <td>10135</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>5</td>
      <td>3</td>
      <td>0</td>
      <td>65893</td>
      <td>...</td>
      <td>Kissy Sullivan</td>
      <td>20.0</td>
      <td>LinkedIn</td>
      <td>Fully Meets</td>
      <td>4.07</td>
      <td>4</td>
      <td>0</td>
      <td>2/28/2019</td>
      <td>0</td>
      <td>13</td>
    </tr>
    <tr>
      <th>112</th>
      <td>Gonzalez, Juan</td>
      <td>10300</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>5</td>
      <td>5</td>
      <td>1</td>
      <td>1</td>
      <td>68898</td>
      <td>...</td>
      <td>Brannon Miller</td>
      <td>12.0</td>
      <td>Diversity Job Fair</td>
      <td>PIP</td>
      <td>3.00</td>
      <td>3</td>
      <td>0</td>
      <td>03/06/2011</td>
      <td>3</td>
      <td>10</td>
    </tr>
    <tr>
      <th>17</th>
      <td>Beatrice, Courtney</td>
      <td>10055</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>5</td>
      <td>3</td>
      <td>0</td>
      <td>59026</td>
      <td>...</td>
      <td>Elijiah Gray</td>
      <td>16.0</td>
      <td>Google Search</td>
      <td>Fully Meets</td>
      <td>5.00</td>
      <td>5</td>
      <td>0</td>
      <td>1/14/2019</td>
      <td>0</td>
      <td>12</td>
    </tr>
  </tbody>
</table>
<p>4 rows × 36 columns</p>
</div>



*editing columns*


```python
dataset.columns = dataset.columns.str.lower()
```

*duplicating dataset*


```python
df = dataset.copy()
```

*data shape*


```python
df.shape
```




    (311, 36)



*data information*


```python
df.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 311 entries, 0 to 310
    Data columns (total 36 columns):
     #   Column                      Non-Null Count  Dtype  
    ---  ------                      --------------  -----  
     0   employee_name               311 non-null    object 
     1   empid                       311 non-null    int64  
     2   marriedid                   311 non-null    int64  
     3   maritalstatusid             311 non-null    int64  
     4   genderid                    311 non-null    int64  
     5   empstatusid                 311 non-null    int64  
     6   deptid                      311 non-null    int64  
     7   perfscoreid                 311 non-null    int64  
     8   fromdiversityjobfairid      311 non-null    int64  
     9   salary                      311 non-null    int64  
     10  termd                       311 non-null    int64  
     11  positionid                  311 non-null    int64  
     12  position                    311 non-null    object 
     13  state                       311 non-null    object 
     14  zip                         311 non-null    int64  
     15  dob                         311 non-null    object 
     16  sex                         311 non-null    object 
     17  maritaldesc                 311 non-null    object 
     18  citizendesc                 311 non-null    object 
     19  hispaniclatino              311 non-null    object 
     20  racedesc                    311 non-null    object 
     21  dateofhire                  311 non-null    object 
     22  dateoftermination           104 non-null    object 
     23  termreason                  311 non-null    object 
     24  employmentstatus            311 non-null    object 
     25  department                  311 non-null    object 
     26  managername                 311 non-null    object 
     27  managerid                   303 non-null    float64
     28  recruitmentsource           311 non-null    object 
     29  performancescore            311 non-null    object 
     30  engagementsurvey            311 non-null    float64
     31  empsatisfaction             311 non-null    int64  
     32  specialprojectscount        311 non-null    int64  
     33  lastperformancereview_date  311 non-null    object 
     34  dayslatelast30              311 non-null    int64  
     35  absences                    311 non-null    int64  
    dtypes: float64(2), int64(16), object(18)
    memory usage: 87.6+ KB


*summary statistics*


```python
df.describe()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>empid</th>
      <th>marriedid</th>
      <th>maritalstatusid</th>
      <th>genderid</th>
      <th>empstatusid</th>
      <th>deptid</th>
      <th>perfscoreid</th>
      <th>fromdiversityjobfairid</th>
      <th>salary</th>
      <th>termd</th>
      <th>positionid</th>
      <th>zip</th>
      <th>managerid</th>
      <th>engagementsurvey</th>
      <th>empsatisfaction</th>
      <th>specialprojectscount</th>
      <th>dayslatelast30</th>
      <th>absences</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>311.000000</td>
      <td>311.000000</td>
      <td>311.000000</td>
      <td>311.000000</td>
      <td>311.000000</td>
      <td>311.000000</td>
      <td>311.000000</td>
      <td>311.000000</td>
      <td>311.000000</td>
      <td>311.000000</td>
      <td>311.000000</td>
      <td>311.000000</td>
      <td>303.000000</td>
      <td>311.000000</td>
      <td>311.000000</td>
      <td>311.000000</td>
      <td>311.000000</td>
      <td>311.000000</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>10156.000000</td>
      <td>0.398714</td>
      <td>0.810289</td>
      <td>0.434084</td>
      <td>2.392283</td>
      <td>4.610932</td>
      <td>2.977492</td>
      <td>0.093248</td>
      <td>69020.684887</td>
      <td>0.334405</td>
      <td>16.845659</td>
      <td>6555.482315</td>
      <td>14.570957</td>
      <td>4.110000</td>
      <td>3.890675</td>
      <td>1.218650</td>
      <td>0.414791</td>
      <td>10.237942</td>
    </tr>
    <tr>
      <th>std</th>
      <td>89.922189</td>
      <td>0.490423</td>
      <td>0.943239</td>
      <td>0.496435</td>
      <td>1.794383</td>
      <td>1.083487</td>
      <td>0.587072</td>
      <td>0.291248</td>
      <td>25156.636930</td>
      <td>0.472542</td>
      <td>6.223419</td>
      <td>16908.396884</td>
      <td>8.078306</td>
      <td>0.789938</td>
      <td>0.909241</td>
      <td>2.349421</td>
      <td>1.294519</td>
      <td>5.852596</td>
    </tr>
    <tr>
      <th>min</th>
      <td>10001.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>0.000000</td>
      <td>45046.000000</td>
      <td>0.000000</td>
      <td>1.000000</td>
      <td>1013.000000</td>
      <td>1.000000</td>
      <td>1.120000</td>
      <td>1.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>1.000000</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>10078.500000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>1.000000</td>
      <td>5.000000</td>
      <td>3.000000</td>
      <td>0.000000</td>
      <td>55501.500000</td>
      <td>0.000000</td>
      <td>18.000000</td>
      <td>1901.500000</td>
      <td>10.000000</td>
      <td>3.690000</td>
      <td>3.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>5.000000</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>10156.000000</td>
      <td>0.000000</td>
      <td>1.000000</td>
      <td>0.000000</td>
      <td>1.000000</td>
      <td>5.000000</td>
      <td>3.000000</td>
      <td>0.000000</td>
      <td>62810.000000</td>
      <td>0.000000</td>
      <td>19.000000</td>
      <td>2132.000000</td>
      <td>15.000000</td>
      <td>4.280000</td>
      <td>4.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>10.000000</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>10233.500000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>5.000000</td>
      <td>5.000000</td>
      <td>3.000000</td>
      <td>0.000000</td>
      <td>72036.000000</td>
      <td>1.000000</td>
      <td>20.000000</td>
      <td>2355.000000</td>
      <td>19.000000</td>
      <td>4.700000</td>
      <td>5.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>15.000000</td>
    </tr>
    <tr>
      <th>max</th>
      <td>10311.000000</td>
      <td>1.000000</td>
      <td>4.000000</td>
      <td>1.000000</td>
      <td>5.000000</td>
      <td>6.000000</td>
      <td>4.000000</td>
      <td>1.000000</td>
      <td>250000.000000</td>
      <td>1.000000</td>
      <td>30.000000</td>
      <td>98052.000000</td>
      <td>39.000000</td>
      <td>5.000000</td>
      <td>5.000000</td>
      <td>8.000000</td>
      <td>6.000000</td>
      <td>20.000000</td>
    </tr>
  </tbody>
</table>
</div>



*null values*


```python
df.isna().sum()
```




    employee_name                   0
    empid                           0
    marriedid                       0
    maritalstatusid                 0
    genderid                        0
    empstatusid                     0
    deptid                          0
    perfscoreid                     0
    fromdiversityjobfairid          0
    salary                          0
    termd                           0
    positionid                      0
    position                        0
    state                           0
    zip                             0
    dob                             0
    sex                             0
    maritaldesc                     0
    citizendesc                     0
    hispaniclatino                  0
    racedesc                        0
    dateofhire                      0
    dateoftermination             207
    termreason                      0
    employmentstatus                0
    department                      0
    managername                     0
    managerid                       8
    recruitmentsource               0
    performancescore                0
    engagementsurvey                0
    empsatisfaction                 0
    specialprojectscount            0
    lastperformancereview_date      0
    dayslatelast30                  0
    absences                        0
    dtype: int64



*duplicates*


```python
df.duplicated().sum()
```




    0



*displaying all columns*


```python
pd.reset_option('display.max_columns', None)
```

*addressing dates*


```python
df['dateofhire'] = pd.to_datetime(df['dateofhire'])  
df['dateoftermination'] = pd.to_datetime(df['dateoftermination'])  
```

*verifying it worked*


```python
df[['dateofhire']].head(9)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>dateofhire</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>2011-07-05</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2015-03-30</td>
    </tr>
    <tr>
      <th>2</th>
      <td>2011-07-05</td>
    </tr>
    <tr>
      <th>3</th>
      <td>2008-01-07</td>
    </tr>
    <tr>
      <th>4</th>
      <td>2011-07-11</td>
    </tr>
    <tr>
      <th>5</th>
      <td>2012-01-09</td>
    </tr>
    <tr>
      <th>6</th>
      <td>2014-11-10</td>
    </tr>
    <tr>
      <th>7</th>
      <td>2013-09-30</td>
    </tr>
    <tr>
      <th>8</th>
      <td>2009-07-06</td>
    </tr>
  </tbody>
</table>
</div>



**finding the average salary of employees**


```python
df['salary'].mean()
```




    69020.6848874598



**finding employee with highest salary**


```python
highest_salary_data = df[df['salary'] == df['salary'].max()]
highest_salary_id = pd.DataFrame(highest_salary_data[['employee_name', 'salary']])
highest_salary_id.columns = ['Employee Name', 'Salary']
highest_salary_id
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Employee Name</th>
      <th>Salary</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>150</th>
      <td>King, Janet</td>
      <td>250000</td>
    </tr>
  </tbody>
</table>
</div>



**finding employee with lowest salary**


```python
lowest_salary_data = df[df['salary'] == df['salary'].min()]
lowest_salary_id = pd.DataFrame(lowest_salary_data[['employee_name', 'salary']])
lowest_salary_id.columns = ['Employee Name', 'Salary']
lowest_salary_id
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Employee Name</th>
      <th>Salary</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>310</th>
      <td>Zima, Colleen</td>
      <td>45046</td>
    </tr>
  </tbody>
</table>
</div>



**finding employee(s) with most absences**


```python
absent_data = df[df['absences'] == df['absences'].max()]
absent_id = pd.DataFrame(absent_data[['employee_name', 'absences']])
absent_id.columns = ['Employee Name', 'Absences']
absent_id
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Employee Name</th>
      <th>Absences</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>15</th>
      <td>Bates, Norman</td>
      <td>20</td>
    </tr>
    <tr>
      <th>93</th>
      <td>Fitzpatrick, Michael  J</td>
      <td>20</td>
    </tr>
    <tr>
      <th>107</th>
      <td>Givens, Myriam</td>
      <td>20</td>
    </tr>
    <tr>
      <th>109</th>
      <td>Goeth, Amon</td>
      <td>20</td>
    </tr>
    <tr>
      <th>114</th>
      <td>Good, Susan</td>
      <td>20</td>
    </tr>
    <tr>
      <th>121</th>
      <td>Guilianno, Mike</td>
      <td>20</td>
    </tr>
    <tr>
      <th>123</th>
      <td>Hankard, Earnest</td>
      <td>20</td>
    </tr>
    <tr>
      <th>155</th>
      <td>Kreuger, Freddy</td>
      <td>20</td>
    </tr>
    <tr>
      <th>158</th>
      <td>Langford, Lindsey</td>
      <td>20</td>
    </tr>
    <tr>
      <th>161</th>
      <td>Latif, Mohammed</td>
      <td>20</td>
    </tr>
    <tr>
      <th>164</th>
      <td>LeBlanc, Brandon  R</td>
      <td>20</td>
    </tr>
    <tr>
      <th>183</th>
      <td>Mckenna, Sandy</td>
      <td>20</td>
    </tr>
    <tr>
      <th>256</th>
      <td>Sloan, Constance</td>
      <td>20</td>
    </tr>
    <tr>
      <th>263</th>
      <td>Sparks, Taylor</td>
      <td>20</td>
    </tr>
  </tbody>
</table>
</div>



**most-tenured employees at the company**


```python
df['hire_year'] = df['dateofhire'].dt.year
tenured = df[['employee_name', 'hire_year']]
tenured.rename(columns = {'employee_name':'Employee Name', 'hire_year':'Hire Year'}, inplace = True)
tenured.sort_values(by = 'Hire Year').head(10)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Employee Name</th>
      <th>Hire Year</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>282</th>
      <td>Torrence, Jack</td>
      <td>2006</td>
    </tr>
    <tr>
      <th>280</th>
      <td>Thibaud, Kenneth</td>
      <td>2007</td>
    </tr>
    <tr>
      <th>222</th>
      <td>Pitt, Brad</td>
      <td>2007</td>
    </tr>
    <tr>
      <th>307</th>
      <td>Ybarra, Catherine</td>
      <td>2008</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Alagbe,Trina</td>
      <td>2008</td>
    </tr>
    <tr>
      <th>29</th>
      <td>Brown, Mia</td>
      <td>2008</td>
    </tr>
    <tr>
      <th>8</th>
      <td>Bachiochi, Linda</td>
      <td>2009</td>
    </tr>
    <tr>
      <th>256</th>
      <td>Sloan, Constance</td>
      <td>2009</td>
    </tr>
    <tr>
      <th>247</th>
      <td>Sadki, Nore</td>
      <td>2009</td>
    </tr>
    <tr>
      <th>276</th>
      <td>Tavares, Desiree</td>
      <td>2009</td>
    </tr>
  </tbody>
</table>
</div>




```python
df['termination_year'] = df['dateoftermination'].dt.year
```

*creating more date time variables*


```python
df['hire_month'] = df['dateofhire'].dt.month_name()
df['termination_month'] = df['dateoftermination'].dt.month_name()

df['hire_day'] = df['dateofhire'].dt.day_name()
df['termination_day'] = df['dateoftermination'].dt.day_name()
```

**employee who has been the most late in the past 30 days**


```python
last_30 = df[df['dayslatelast30'] == df['dayslatelast30'].max()]
```


```python
last_30_id = pd.DataFrame(last_30[['employee_name', 'dayslatelast30']])
last_30_id.columns = ['Employee Name', 'Days Late In The Past Month']
last_30_id
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Employee Name</th>
      <th>Days Late In The Past Month</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>67</th>
      <td>Delarge, Alex</td>
      <td>6</td>
    </tr>
    <tr>
      <th>90</th>
      <td>Fernandes, Nilson</td>
      <td>6</td>
    </tr>
    <tr>
      <th>188</th>
      <td>Miller, Ned</td>
      <td>6</td>
    </tr>
    <tr>
      <th>205</th>
      <td>O'hare, Lynn</td>
      <td>6</td>
    </tr>
    <tr>
      <th>263</th>
      <td>Sparks, Taylor</td>
      <td>6</td>
    </tr>
    <tr>
      <th>297</th>
      <td>Wallace, Theresa</td>
      <td>6</td>
    </tr>
  </tbody>
</table>
</div>



**most popular year to get hired**


```python
popular_hr_date = df['hire_year'].value_counts(ascending = True)
plt.figure(figsize = (17, 9))
popular_hr_date.plot(kind = 'barh', edgecolor = 'black', color = ['dimgray', 'deeppink', 'skyblue', 'gold', 'tomato', 'teal', 'navy', 'peachpuff','red'])
plt.title('\nMost Popular Hiring Years At The Company\n', fontsize = 11)
plt.ylabel('')
plt.xlabel('\nNumber of People Hired', fontsize = 9.5)
plt.show()
```


    
![png](output_44_0.png)
    


**most popular month to get hired**


```python
popular_hr_month = df['hire_month'].value_counts(ascending = True)
plt.figure(figsize = (17, 9))
popular_hr_month.plot(kind = 'barh', edgecolor = 'black', color = ['darkorange', 'deeppink', 'skyblue', 'gold', 'lime', 'tomato', 'teal', 'navy', 'peachpuff','red'])
plt.title('\nMost Popular Hiring Months At The Company\n', fontsize = 11)
plt.ylabel('')
plt.xlabel('\nNumber of People Hired', fontsize = 9.5)
plt.show()
```


    
![png](output_46_0.png)
    


**most popular day to get hired**


```python
popular_hr_day = df['hire_day'].value_counts(ascending = True)
plt.figure(figsize = (17, 6))
popular_hr_day.plot(kind = 'barh', edgecolor = 'black', color = ['dimgray', 'deeppink', 'skyblue', 'gold', 'tomato', 'teal', 'navy', 'peachpuff','red'])
plt.title('\nMost Popular Hiring Days At The Company\n', fontsize = 11)
plt.ylabel('')
plt.xlabel('\nNumber of People Hired', fontsize = 9.5)
plt.show()
```


    
![png](output_48_0.png)
    


**most popular years to get terminated**


```python
popular_tr_years = df['termination_year'].value_counts(ascending = True)
plt.figure(figsize = (17, 9))
popular_tr_years.plot(kind = 'barh', edgecolor = 'black', color = ['dimgray', 'deeppink', 'skyblue', 'gold', 'tomato', 'teal', 'navy', 'peachpuff','red'])
plt.title('\nMost Popular Termination Years At The Company\n', fontsize = 11)
plt.ylabel('')
plt.xlabel('\nNumber of People Fired', fontsize = 9.5)
plt.show()
```


    
![png](output_50_0.png)
    


**most popular months to get terminated**


```python
popular_tr_months = df['termination_month'].value_counts(ascending = True)
plt.figure(figsize = (17, 9))
popular_tr_months.plot(kind = 'barh', edgecolor = 'black', color = ['dimgray', 'deeppink', 'skyblue', 'gold', 'tomato', 'teal', 'navy', 'peachpuff','red'])
plt.title('\nMost Popular Termination Months At The Company\n', fontsize = 11)
plt.ylabel('')
plt.xlabel('\nNumber of People Fired', fontsize = 9.5)
plt.show()
```


    
![png](output_52_0.png)
    


**most popular days to get terminated**


```python
popular_tr_days = df['termination_day'].value_counts(ascending = True)
plt.figure(figsize = (17, 6))
popular_tr_days.plot(kind = 'barh', edgecolor = 'black', color = ['dimgray', 'deeppink', 'skyblue', 'gold', 'tomato', 'teal', 'navy', 'peachpuff','red'])
plt.title('\nMost Popular Termination Days At The Company\n', fontsize = 11)
plt.ylabel('')
plt.xlabel('\nNumber of People Fired', fontsize = 9.5)
plt.show()
```


    
![png](output_54_0.png)
    


**salary distribution**


```python
plt.figure(figsize = (12, 5))
plt.hist(df['salary'], edgecolor = 'black', color = 'peachpuff', density = True, bins = 31)
sns.kdeplot(df['salary'], color = 'tomato', linewidth = 2.2, linestyle = '--')
plt.title('Salary Distribution', fontsize = 11)
plt.xlabel('Salary', fontsize = 9.5)
plt.ylabel('Freqency', fontsize = 9.5)
plt.show()
```


    
![png](output_56_0.png)
    


**positions at the company**


```python
positions_count = df['position'].value_counts(ascending = False)
pd.DataFrame(positions_count)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>count</th>
    </tr>
    <tr>
      <th>position</th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>Production Technician I</th>
      <td>137</td>
    </tr>
    <tr>
      <th>Production Technician II</th>
      <td>57</td>
    </tr>
    <tr>
      <th>Area Sales Manager</th>
      <td>27</td>
    </tr>
    <tr>
      <th>Production Manager</th>
      <td>14</td>
    </tr>
    <tr>
      <th>Software Engineer</th>
      <td>10</td>
    </tr>
    <tr>
      <th>IT Support</th>
      <td>8</td>
    </tr>
    <tr>
      <th>Data Analyst</th>
      <td>7</td>
    </tr>
    <tr>
      <th>Sr. Network Engineer</th>
      <td>5</td>
    </tr>
    <tr>
      <th>Database Administrator</th>
      <td>5</td>
    </tr>
    <tr>
      <th>Network Engineer</th>
      <td>5</td>
    </tr>
    <tr>
      <th>BI Developer</th>
      <td>4</td>
    </tr>
    <tr>
      <th>Senior BI Developer</th>
      <td>3</td>
    </tr>
    <tr>
      <th>Administrative Assistant</th>
      <td>3</td>
    </tr>
    <tr>
      <th>Sales Manager</th>
      <td>3</td>
    </tr>
    <tr>
      <th>Accountant I</th>
      <td>3</td>
    </tr>
    <tr>
      <th>Sr. DBA</th>
      <td>2</td>
    </tr>
    <tr>
      <th>IT Manager - DB</th>
      <td>2</td>
    </tr>
    <tr>
      <th>Sr. Accountant</th>
      <td>2</td>
    </tr>
    <tr>
      <th>Director of Operations</th>
      <td>1</td>
    </tr>
    <tr>
      <th>Shared Services Manager</th>
      <td>1</td>
    </tr>
    <tr>
      <th>Data Analyst</th>
      <td>1</td>
    </tr>
    <tr>
      <th>Data Architect</th>
      <td>1</td>
    </tr>
    <tr>
      <th>Principal Data Architect</th>
      <td>1</td>
    </tr>
    <tr>
      <th>IT Manager - Infra</th>
      <td>1</td>
    </tr>
    <tr>
      <th>President &amp; CEO</th>
      <td>1</td>
    </tr>
    <tr>
      <th>Enterprise Architect</th>
      <td>1</td>
    </tr>
    <tr>
      <th>BI Director</th>
      <td>1</td>
    </tr>
    <tr>
      <th>Director of Sales</th>
      <td>1</td>
    </tr>
    <tr>
      <th>IT Director</th>
      <td>1</td>
    </tr>
    <tr>
      <th>IT Manager - Support</th>
      <td>1</td>
    </tr>
    <tr>
      <th>Software Engineering Manager</th>
      <td>1</td>
    </tr>
    <tr>
      <th>CIO</th>
      <td>1</td>
    </tr>
  </tbody>
</table>
</div>



**most popular positions at the company**


```python
plt.figure(figsize = (17, 5))
positions_count.head(5).plot(kind = 'barh', edgecolor = 'black', color = ['deeppink', 'skyblue', 'gold', 'tomato', 'teal', 'navy', 'peachpuff','red'])
plt.title('\nTop 5 Popular Positions At The Company\n', fontsize = 11)
plt.xlabel('\nNumber Of People In The Position', fontsize = 9.5)
plt.ylabel('')
plt.show()
```


    
![png](output_60_0.png)
    


**least popular positions at the company**


```python
plt.figure(figsize = (17, 5))
positions_count.tail(5).plot(kind = 'barh', edgecolor = 'black', color = ['deeppink', 'skyblue', 'gold', 'tomato', 'teal', 'navy', 'peachpuff','red'])
plt.title('\nLeast Positions At The Company\n', fontsize = 11)
plt.xlabel('\nNumber Of People In The Position', fontsize = 9.5)
plt.ylabel('')
plt.show()
```


    
![png](output_62_0.png)
    


**state representation at the company**


```python
state_repr = df['state'].value_counts(ascending = False)
pd.DataFrame(state_repr)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>count</th>
    </tr>
    <tr>
      <th>state</th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>MA</th>
      <td>276</td>
    </tr>
    <tr>
      <th>CT</th>
      <td>6</td>
    </tr>
    <tr>
      <th>TX</th>
      <td>3</td>
    </tr>
    <tr>
      <th>VT</th>
      <td>2</td>
    </tr>
    <tr>
      <th>UT</th>
      <td>1</td>
    </tr>
    <tr>
      <th>AZ</th>
      <td>1</td>
    </tr>
    <tr>
      <th>ND</th>
      <td>1</td>
    </tr>
    <tr>
      <th>OR</th>
      <td>1</td>
    </tr>
    <tr>
      <th>MT</th>
      <td>1</td>
    </tr>
    <tr>
      <th>NV</th>
      <td>1</td>
    </tr>
    <tr>
      <th>ID</th>
      <td>1</td>
    </tr>
    <tr>
      <th>KY</th>
      <td>1</td>
    </tr>
    <tr>
      <th>NC</th>
      <td>1</td>
    </tr>
    <tr>
      <th>FL</th>
      <td>1</td>
    </tr>
    <tr>
      <th>GA</th>
      <td>1</td>
    </tr>
    <tr>
      <th>CO</th>
      <td>1</td>
    </tr>
    <tr>
      <th>NY</th>
      <td>1</td>
    </tr>
    <tr>
      <th>PA</th>
      <td>1</td>
    </tr>
    <tr>
      <th>RI</th>
      <td>1</td>
    </tr>
    <tr>
      <th>NH</th>
      <td>1</td>
    </tr>
    <tr>
      <th>TN</th>
      <td>1</td>
    </tr>
    <tr>
      <th>IN</th>
      <td>1</td>
    </tr>
    <tr>
      <th>OH</th>
      <td>1</td>
    </tr>
    <tr>
      <th>CA</th>
      <td>1</td>
    </tr>
    <tr>
      <th>WA</th>
      <td>1</td>
    </tr>
    <tr>
      <th>AL</th>
      <td>1</td>
    </tr>
    <tr>
      <th>VA</th>
      <td>1</td>
    </tr>
    <tr>
      <th>ME</th>
      <td>1</td>
    </tr>
  </tbody>
</table>
</div>



**most represented states at the company**


```python
plt.figure(figsize = (17, 5))
state_repr.head(5).plot(kind = 'barh', edgecolor = 'black', color = ['deeppink', 'skyblue', 'gold', 'tomato', 'teal', 'navy', 'peachpuff','red'])
plt.title('\nTop 5 Represented States At The Company\n', fontsize = 11)
plt.xlabel('\nNumber Of People From State', fontsize = 9.5)
plt.ylabel('')
plt.show()
```


    
![png](output_66_0.png)
    


**most represented zipcodes at the company**


```python
repr_zipcodes = df['zip'].value_counts(ascending = False)
repr_zipcodes.head(5).plot(kind = 'pie', autopct = '%1.1f%%')
plt.title('Most Represented Zip Codes', fontsize = 11)
plt.xlabel('')
plt.ylabel('')
plt.show()
```


    
![png](output_68_0.png)
    


*making birthday datetime*


```python
df['dob'] = pd.to_datetime(df['dob'],  format='%m/%d/%y', errors='coerce')

df['birth_year'] = df['dob'].dt.year
df['birth_month'] = df['dob'].dt.month_name()
df['birth_day'] = df['dob'].dt.day_name()
```

**most popular employee birth years**


```python
pd.DataFrame(df['birth_year'].value_counts(ascending = False).head(5))
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>count</th>
    </tr>
    <tr>
      <th>birth_year</th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>1987.0</th>
      <td>14</td>
    </tr>
    <tr>
      <th>1979.0</th>
      <td>12</td>
    </tr>
    <tr>
      <th>1983.0</th>
      <td>11</td>
    </tr>
    <tr>
      <th>1988.0</th>
      <td>10</td>
    </tr>
    <tr>
      <th>1985.0</th>
      <td>9</td>
    </tr>
  </tbody>
</table>
</div>



**oldest employees at the company**


```python
oldest_employees = df[df['birth_year'] == df['birth_year'].min()]
oldest_employees_id = pd.DataFrame(oldest_employees[['employee_name', 'birth_year']])
oldest_employees_id.columns = ['Employee Name', 'Birth Year']
oldest_employees_id
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Employee Name</th>
      <th>Birth Year</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>31</th>
      <td>Bugali, Josephine</td>
      <td>1969.0</td>
    </tr>
    <tr>
      <th>111</th>
      <td>Gonzalez, Cayo</td>
      <td>1969.0</td>
    </tr>
    <tr>
      <th>155</th>
      <td>Kreuger, Freddy</td>
      <td>1969.0</td>
    </tr>
    <tr>
      <th>287</th>
      <td>Turpin, Jumil</td>
      <td>1969.0</td>
    </tr>
  </tbody>
</table>
</div>



**most popular employee birth months**


```python
month_representation = df['birth_month'].value_counts(ascending = False)

plt.figure(figsize = (17, 6))
month_representation.head(5).plot(kind = 'barh', edgecolor = 'black', color = ['deeppink', 'skyblue', 'gold', 'tomato', 'teal', 'navy', 'peachpuff','red'])
plt.title('\nTop 5 Popular Birth Months At The Company\n', fontsize = 11)
plt.xlabel('\nNumber Of People Born That Month', fontsize = 9.5)
plt.ylabel('')
plt.show()
```


    
![png](output_76_0.png)
    


**most popular employee birth days**


```python
day_representation = df['birth_day'].value_counts(ascending = False)

plt.figure(figsize = (17, 8))
day_representation.plot(kind = 'barh', edgecolor = 'black', color = ['deeppink', 'skyblue', 'gold', 'tomato', 'teal', 'navy', 'peachpuff','red'])
plt.title('\nTop 5 Popular Birth Days At The Company\n', fontsize = 11)
plt.xlabel('\nNumber Of People Born That Day', fontsize = 9.5)
plt.ylabel('')
plt.show()
```


    
![png](output_78_0.png)
    


**employee gender distribution**


```python
gender_dist = df['sex'].value_counts()
gender_dist.plot(kind = 'pie', autopct = '%1.1f%%')
plt.title('Employee Gender Distribution', fontsize = 11)
plt.xlabel('')
plt.ylabel('')
plt.show()
```


    
![png](output_80_0.png)
    


**Employee Marital Status Distribution**


```python
martital_dist = df['maritaldesc'].value_counts(ascending = False)

plt.figure(figsize = (17, 6))
martital_dist.plot(kind = 'barh', edgecolor = 'black', color = ['deeppink', 'skyblue', 'gold', 'tomato', 'teal', 'navy', 'peachpuff','red'])
plt.title('\nEmployee Marital Distribution\n', fontsize = 11)
plt.xlabel('\nNumber Of People In This Marital Category', fontsize = 9.5)
plt.ylabel('')
plt.show()
```


    
![png](output_82_0.png)
    


**Employee Citizenship Status Distribution**


```python
citizen_dist = df['citizendesc'].value_counts(ascending = False)

plt.figure(figsize = (17, 4))
citizen_dist.plot(kind = 'barh', edgecolor = 'black', color = ['deeppink', 'skyblue', 'gold', 'tomato', 'teal', 'navy', 'peachpuff','red'])
plt.title('\nEmployee Citizenship Status Distribution\n', fontsize = 11)
plt.xlabel('\nCount', fontsize = 9.5)
plt.ylabel('')
plt.show()
```


    
![png](output_84_0.png)
    


**Employee Racial Distribution**


```python
race_dist = df['racedesc'].value_counts(ascending = False)

plt.figure(figsize = (17, 7))
race_dist.plot(kind = 'barh', edgecolor = 'black', color = ['deeppink', 'skyblue', 'gold', 'tomato', 'teal', 'navy', 'peachpuff','red'])
plt.title('\nEmployee Racial Distribution\n', fontsize = 11)
plt.xlabel('\nTotal Number From Race', fontsize = 9.5)
plt.ylabel('')
plt.show()
```


    
![png](output_86_0.png)
    


**Most Popular Reasons For Terminating Employees**


```python
term_reason = df['termreason'].value_counts(ascending = False)
term_plot = term_reason.iloc[2:]
pd.DataFrame(term_plot)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>count</th>
    </tr>
    <tr>
      <th>termreason</th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>unhappy</th>
      <td>14</td>
    </tr>
    <tr>
      <th>more money</th>
      <td>11</td>
    </tr>
    <tr>
      <th>career change</th>
      <td>9</td>
    </tr>
    <tr>
      <th>hours</th>
      <td>8</td>
    </tr>
    <tr>
      <th>attendance</th>
      <td>7</td>
    </tr>
    <tr>
      <th>return to school</th>
      <td>5</td>
    </tr>
    <tr>
      <th>relocation out of area</th>
      <td>5</td>
    </tr>
    <tr>
      <th>no-call, no-show</th>
      <td>4</td>
    </tr>
    <tr>
      <th>military</th>
      <td>4</td>
    </tr>
    <tr>
      <th>retiring</th>
      <td>4</td>
    </tr>
    <tr>
      <th>performance</th>
      <td>4</td>
    </tr>
    <tr>
      <th>maternity leave - did not return</th>
      <td>3</td>
    </tr>
    <tr>
      <th>medical issues</th>
      <td>3</td>
    </tr>
    <tr>
      <th>Learned that he is a gangster</th>
      <td>1</td>
    </tr>
    <tr>
      <th>Fatal attraction</th>
      <td>1</td>
    </tr>
    <tr>
      <th>gross misconduct</th>
      <td>1</td>
    </tr>
  </tbody>
</table>
</div>




```python
plt.figure(figsize = (17, 6))
term_plot.head(5).plot(kind = 'barh', edgecolor = 'black', color = ['deeppink', 'skyblue', 'gold', 'tomato', 'teal', 'navy', 'peachpuff','red'])
plt.title('\nTop 5 Reasons For Employee Termination/Leave\n', fontsize = 11)
plt.xlabel('\nNumber Of Employees Fired/Left For This Reason', fontsize = 9.5)
plt.ylabel('')
plt.show()
```


    
![png](output_89_0.png)
    


**Employee Employment Status Distribution**


```python
empl_status = df['employmentstatus'].value_counts(ascending = False)
empl_status.plot(kind = 'pie', autopct = '%1.1f%%')
plt.title('Employee Employment Status Distribution', fontsize = 11)
plt.xlabel('')
plt.ylabel('')
plt.show()
```


    
![png](output_91_0.png)
    


**Employee Department Distribution**


```python
dept_dist = df['department'].value_counts(ascending = False)
plt.figure(figsize = (9, 9))
dept_dist.plot(kind = 'pie', autopct = '%1.1f%%')
plt.title('Employee Department Distribution', fontsize = 14)
plt.xlabel('')
plt.ylabel('')
plt.show()
```


    
![png](output_93_0.png)
    


**Most Influential Managers**


```python
infl_mng = df['managername'].value_counts(ascending = False).head(5)
a = pd.DataFrame(infl_mng)
a.columns = ['Number Of Supervisees']
a
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Number Of Supervisees</th>
    </tr>
    <tr>
      <th>managername</th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>Michael Albert</th>
      <td>22</td>
    </tr>
    <tr>
      <th>Kissy Sullivan</th>
      <td>22</td>
    </tr>
    <tr>
      <th>Elijiah Gray</th>
      <td>22</td>
    </tr>
    <tr>
      <th>Kelley Spirea</th>
      <td>22</td>
    </tr>
    <tr>
      <th>Brannon Miller</th>
      <td>22</td>
    </tr>
  </tbody>
</table>
</div>



**Recruitement Souces Distribution**


```python
recmt_dist = df['recruitmentsource'].value_counts(ascending = False)
a = pd.DataFrame(recmt_dist)
a.columns = ['Number Of Employees Recruited']
a
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Number Of Employees Recruited</th>
    </tr>
    <tr>
      <th>recruitmentsource</th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>Indeed</th>
      <td>87</td>
    </tr>
    <tr>
      <th>LinkedIn</th>
      <td>76</td>
    </tr>
    <tr>
      <th>Google Search</th>
      <td>49</td>
    </tr>
    <tr>
      <th>Employee Referral</th>
      <td>31</td>
    </tr>
    <tr>
      <th>Diversity Job Fair</th>
      <td>29</td>
    </tr>
    <tr>
      <th>CareerBuilder</th>
      <td>23</td>
    </tr>
    <tr>
      <th>Website</th>
      <td>13</td>
    </tr>
    <tr>
      <th>Other</th>
      <td>2</td>
    </tr>
    <tr>
      <th>On-line Web application</th>
      <td>1</td>
    </tr>
  </tbody>
</table>
</div>




```python
plt.figure(figsize = (17, 6))
recmt_dist.head(5).plot(kind = 'barh', edgecolor = 'black', color = ['deeppink', 'skyblue', 'gold', 'tomato', 'teal', 'navy', 'peachpuff','red'])
plt.title('\nTop 5 Recruitment Platforms\n', fontsize = 11)
plt.xlabel('\nNumber Of Employees Hired From Platform', fontsize = 9.5)
plt.ylabel('')
plt.show()
```


    
![png](output_98_0.png)
    


**Employees That Exceed Performance**


```python
perf_scre = df[df['performancescore'] == 'Exceeds']
perf_scre_id = pd.DataFrame(perf_scre[['employee_name','performancescore']])
perf_scre_id.columns = ['Employee Name', 'Exceptional Performance Proof']
len_perf_scre_id = len(perf_scre_id)
perf_scre_id
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Employee Name</th>
      <th>Exceptional Performance Proof</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Adinolfi, Wilson  K</td>
      <td>Exceeds</td>
    </tr>
    <tr>
      <th>5</th>
      <td>Anderson, Linda</td>
      <td>Exceeds</td>
    </tr>
    <tr>
      <th>12</th>
      <td>Barbossa, Hector</td>
      <td>Exceeds</td>
    </tr>
    <tr>
      <th>16</th>
      <td>Beak, Kimberly</td>
      <td>Exceeds</td>
    </tr>
    <tr>
      <th>22</th>
      <td>Billis, Helen</td>
      <td>Exceeds</td>
    </tr>
    <tr>
      <th>36</th>
      <td>Candie, Calvin</td>
      <td>Exceeds</td>
    </tr>
    <tr>
      <th>51</th>
      <td>Clukey, Elijian</td>
      <td>Exceeds</td>
    </tr>
    <tr>
      <th>55</th>
      <td>Corleone, Vito</td>
      <td>Exceeds</td>
    </tr>
    <tr>
      <th>76</th>
      <td>Dougall, Eric</td>
      <td>Exceeds</td>
    </tr>
    <tr>
      <th>77</th>
      <td>Driver, Elle</td>
      <td>Exceeds</td>
    </tr>
    <tr>
      <th>96</th>
      <td>Foss, Jason</td>
      <td>Exceeds</td>
    </tr>
    <tr>
      <th>106</th>
      <td>Girifalco, Evelyn</td>
      <td>Exceeds</td>
    </tr>
    <tr>
      <th>111</th>
      <td>Gonzalez, Cayo</td>
      <td>Exceeds</td>
    </tr>
    <tr>
      <th>125</th>
      <td>Harrison, Kara</td>
      <td>Exceeds</td>
    </tr>
    <tr>
      <th>141</th>
      <td>Jeannite, Tayana</td>
      <td>Exceeds</td>
    </tr>
    <tr>
      <th>143</th>
      <td>Johnson, George</td>
      <td>Exceeds</td>
    </tr>
    <tr>
      <th>145</th>
      <td>Johnston, Yen</td>
      <td>Exceeds</td>
    </tr>
    <tr>
      <th>167</th>
      <td>Liebig, Ketsia</td>
      <td>Exceeds</td>
    </tr>
    <tr>
      <th>170</th>
      <td>Lindsay, Leonara</td>
      <td>Exceeds</td>
    </tr>
    <tr>
      <th>172</th>
      <td>Lunquist, Lisa</td>
      <td>Exceeds</td>
    </tr>
    <tr>
      <th>174</th>
      <td>Lynch, Lindsay</td>
      <td>Exceeds</td>
    </tr>
    <tr>
      <th>191</th>
      <td>Monterro, Luisa</td>
      <td>Exceeds</td>
    </tr>
    <tr>
      <th>201</th>
      <td>Ngodup, Shari</td>
      <td>Exceeds</td>
    </tr>
    <tr>
      <th>208</th>
      <td>Osturnka, Adeel</td>
      <td>Exceeds</td>
    </tr>
    <tr>
      <th>212</th>
      <td>Patronick, Lucas</td>
      <td>Exceeds</td>
    </tr>
    <tr>
      <th>217</th>
      <td>Peters, Lauren</td>
      <td>Exceeds</td>
    </tr>
    <tr>
      <th>220</th>
      <td>Petrowsky, Thelma</td>
      <td>Exceeds</td>
    </tr>
    <tr>
      <th>232</th>
      <td>Rivera, Haley</td>
      <td>Exceeds</td>
    </tr>
    <tr>
      <th>237</th>
      <td>Robinson, Elias</td>
      <td>Exceeds</td>
    </tr>
    <tr>
      <th>257</th>
      <td>Smith, Joe</td>
      <td>Exceeds</td>
    </tr>
    <tr>
      <th>265</th>
      <td>Squatrito, Kristen</td>
      <td>Exceeds</td>
    </tr>
    <tr>
      <th>274</th>
      <td>Szabo, Andrew</td>
      <td>Exceeds</td>
    </tr>
    <tr>
      <th>282</th>
      <td>Torrence, Jack</td>
      <td>Exceeds</td>
    </tr>
    <tr>
      <th>289</th>
      <td>Veera, Abdellah</td>
      <td>Exceeds</td>
    </tr>
    <tr>
      <th>293</th>
      <td>Volk, Colleen</td>
      <td>Exceeds</td>
    </tr>
    <tr>
      <th>304</th>
      <td>Winthrop, Jordan</td>
      <td>Exceeds</td>
    </tr>
    <tr>
      <th>308</th>
      <td>Zamora, Jennifer</td>
      <td>Exceeds</td>
    </tr>
  </tbody>
</table>
</div>



###
**37** out of the **311** employees **exceeded performance**
####

**Employee Engagement Survery Statistics**


```python
df['engagementsurvey'].describe()
```




    count    311.000000
    mean       4.110000
    std        0.789938
    min        1.120000
    25%        3.690000
    50%        4.280000
    75%        4.700000
    max        5.000000
    Name: engagementsurvey, dtype: float64



####
The average employee engagement survey score is **4.11**

The highest employee engagement survey score is **5.0**

The lowest employee engagement survey score is **1.12**

####
**Employee Engagement Survey Scores Distribution**


```python
plt.figure(figsize = (12, 5))
plt.hist(df['engagementsurvey'], edgecolor = 'black', color = 'skyblue', density = True, bins = 21)
sns.kdeplot(df['engagementsurvey'], color = 'navy', linewidth = 2.2, linestyle = '--')
plt.title('\nEngagement Survey Scores Distribution\n', fontsize = 11)
plt.xlabel('\nScore (Out of 5)', fontsize = 9.5)
plt.ylabel('Freqency', fontsize = 9.5)
plt.show()
```


    
![png](output_106_0.png)
    


**Employee Satisfaction Score Statistics**


```python
df['empsatisfaction'].describe()
```




    count    311.000000
    mean       3.890675
    std        0.909241
    min        1.000000
    25%        3.000000
    50%        4.000000
    75%        5.000000
    max        5.000000
    Name: empsatisfaction, dtype: float64



####
The average employee satisfaction score is **3.89**

The highest employee satisfaction score is **5.0**

The lowest employee satisfaction score is **1.0**

####
**Employee Satisfaction Scores Distribution**


```python
plt.figure(figsize = (12, 5))
plt.hist(df['empsatisfaction'], edgecolor = 'black', color = 'pink', density = True, bins = 5)
sns.kdeplot(df['empsatisfaction'], color = 'deeppink', linewidth = 2.2, linestyle = '--')
plt.title('\nEngagement Satisfaction Scores Distribution\n', fontsize = 11)
plt.xlabel('\nScore (Out of 5)', fontsize = 9.5)
plt.ylabel('Freqency', fontsize = 9.5)
plt.show()
```


    
![png](output_111_0.png)
    


**Special Projects Distribution**


```python
plt.figure(figsize = (12, 5))
plt.hist(df['specialprojectscount'], edgecolor = 'black', color = 'lightgreen', density = True, bins = 8)
sns.kdeplot(df['specialprojectscount'], color = 'mediumseagreen', linewidth = 2.2, linestyle = '--')
plt.title('\nSpecial Projects By Employees Distribution\n', fontsize = 11)
plt.xlabel('\nNumber Of Projects', fontsize = 9.5)
plt.ylabel('Freqency', fontsize = 9.5)
plt.show()
```


    
![png](output_113_0.png)
    


## Salary Analysis

1. What is the average salary by department?


```python
a = pd.DataFrame(df.groupby('department')['salary'].mean().sort_values(ascending = False))
a.columns = ['Average Salary']
a
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Average Salary</th>
    </tr>
    <tr>
      <th>department</th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>Executive Office</th>
      <td>250000.000000</td>
    </tr>
    <tr>
      <th>IT/IS</th>
      <td>97064.640000</td>
    </tr>
    <tr>
      <th>Software Engineering</th>
      <td>94989.454545</td>
    </tr>
    <tr>
      <th>Admin Offices</th>
      <td>71791.888889</td>
    </tr>
    <tr>
      <th>Sales</th>
      <td>69061.258065</td>
    </tr>
    <tr>
      <th>Production</th>
      <td>59953.545455</td>
    </tr>
  </tbody>
</table>
</div>



#####
2. What is the maximum salary for each position?


```python
a = pd.DataFrame(df.groupby('position')['salary'].max().sort_values(ascending = False))
a.columns = ['Maximum Salary']
a
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Maximum Salary</th>
    </tr>
    <tr>
      <th>position</th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>President &amp; CEO</th>
      <td>250000</td>
    </tr>
    <tr>
      <th>CIO</th>
      <td>220450</td>
    </tr>
    <tr>
      <th>Director of Sales</th>
      <td>180000</td>
    </tr>
    <tr>
      <th>IT Director</th>
      <td>178000</td>
    </tr>
    <tr>
      <th>Director of Operations</th>
      <td>170500</td>
    </tr>
    <tr>
      <th>IT Manager - Infra</th>
      <td>157000</td>
    </tr>
    <tr>
      <th>Data Architect</th>
      <td>150290</td>
    </tr>
    <tr>
      <th>IT Manager - DB</th>
      <td>148999</td>
    </tr>
    <tr>
      <th>IT Manager - Support</th>
      <td>138888</td>
    </tr>
    <tr>
      <th>Principal Data Architect</th>
      <td>120000</td>
    </tr>
    <tr>
      <th>Database Administrator</th>
      <td>114800</td>
    </tr>
    <tr>
      <th>BI Director</th>
      <td>110929</td>
    </tr>
    <tr>
      <th>Software Engineer</th>
      <td>108987</td>
    </tr>
    <tr>
      <th>Sr. Network Engineer</th>
      <td>107226</td>
    </tr>
    <tr>
      <th>Sr. Accountant</th>
      <td>106367</td>
    </tr>
    <tr>
      <th>Sr. DBA</th>
      <td>104437</td>
    </tr>
    <tr>
      <th>Enterprise Architect</th>
      <td>103613</td>
    </tr>
    <tr>
      <th>BI Developer</th>
      <td>99020</td>
    </tr>
    <tr>
      <th>Data Analyst</th>
      <td>93554</td>
    </tr>
    <tr>
      <th>Shared Services Manager</th>
      <td>93046</td>
    </tr>
    <tr>
      <th>Production Manager</th>
      <td>88976</td>
    </tr>
    <tr>
      <th>Data Analyst</th>
      <td>88527</td>
    </tr>
    <tr>
      <th>Senior BI Developer</th>
      <td>87921</td>
    </tr>
    <tr>
      <th>Software Engineering Manager</th>
      <td>77692</td>
    </tr>
    <tr>
      <th>Network Engineer</th>
      <td>76029</td>
    </tr>
    <tr>
      <th>Production Technician II</th>
      <td>74813</td>
    </tr>
    <tr>
      <th>IT Support</th>
      <td>74679</td>
    </tr>
    <tr>
      <th>Area Sales Manager</th>
      <td>74326</td>
    </tr>
    <tr>
      <th>Sales Manager</th>
      <td>72992</td>
    </tr>
    <tr>
      <th>Production Technician I</th>
      <td>64991</td>
    </tr>
    <tr>
      <th>Accountant I</th>
      <td>64520</td>
    </tr>
    <tr>
      <th>Administrative Assistant</th>
      <td>55000</td>
    </tr>
  </tbody>
</table>
</div>



#####
3. What is the minimum salary by state?


```python
a = pd.DataFrame(df.groupby('state')['salary'].min().sort_values(ascending = False))
a.columns = ['Minimum Salary']
a
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Minimum Salary</th>
    </tr>
    <tr>
      <th>state</th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>RI</th>
      <td>180000</td>
    </tr>
    <tr>
      <th>VA</th>
      <td>74326</td>
    </tr>
    <tr>
      <th>CA</th>
      <td>74241</td>
    </tr>
    <tr>
      <th>TN</th>
      <td>71707</td>
    </tr>
    <tr>
      <th>NY</th>
      <td>71339</td>
    </tr>
    <tr>
      <th>NH</th>
      <td>70545</td>
    </tr>
    <tr>
      <th>UT</th>
      <td>70468</td>
    </tr>
    <tr>
      <th>PA</th>
      <td>68999</td>
    </tr>
    <tr>
      <th>NC</th>
      <td>68829</td>
    </tr>
    <tr>
      <th>VT</th>
      <td>65729</td>
    </tr>
    <tr>
      <th>CO</th>
      <td>65310</td>
    </tr>
    <tr>
      <th>ND</th>
      <td>64397</td>
    </tr>
    <tr>
      <th>GA</th>
      <td>63695</td>
    </tr>
    <tr>
      <th>TX</th>
      <td>63291</td>
    </tr>
    <tr>
      <th>FL</th>
      <td>63051</td>
    </tr>
    <tr>
      <th>KY</th>
      <td>61844</td>
    </tr>
    <tr>
      <th>ID</th>
      <td>61809</td>
    </tr>
    <tr>
      <th>AL</th>
      <td>61568</td>
    </tr>
    <tr>
      <th>IN</th>
      <td>61555</td>
    </tr>
    <tr>
      <th>MT</th>
      <td>60120</td>
    </tr>
    <tr>
      <th>OH</th>
      <td>59370</td>
    </tr>
    <tr>
      <th>WA</th>
      <td>59231</td>
    </tr>
    <tr>
      <th>OR</th>
      <td>58370</td>
    </tr>
    <tr>
      <th>NV</th>
      <td>58273</td>
    </tr>
    <tr>
      <th>AZ</th>
      <td>57859</td>
    </tr>
    <tr>
      <th>ME</th>
      <td>55875</td>
    </tr>
    <tr>
      <th>CT</th>
      <td>51777</td>
    </tr>
    <tr>
      <th>MA</th>
      <td>45046</td>
    </tr>
  </tbody>
</table>
</div>



#####
4. How does the median salary vary by employment status?


```python
a = pd.DataFrame(df.groupby('employmentstatus')['salary'].median().sort_values(ascending = False))
a.columns = ['Median Salary']
a
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Median Salary</th>
    </tr>
    <tr>
      <th>employmentstatus</th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>Active</th>
      <td>63051.0</td>
    </tr>
    <tr>
      <th>Terminated for Cause</th>
      <td>60881.0</td>
    </tr>
    <tr>
      <th>Voluntarily Terminated</th>
      <td>60512.0</td>
    </tr>
  </tbody>
</table>
</div>



#####
5. What is the total salary cost by department?


```python
a = pd.DataFrame(df.groupby('department')['salary'].sum().sort_values(ascending = False))
a.plot(kind = 'barh', edgecolor = 'black', color = ['deeppink', 'skyblue', 'gold', 'tomato', 'teal', 'navy', 'peachpuff','red'], figsize = (17, 6))
plt.title('\nTotal Salary Cost By Department\n', fontsize = 11)
plt.xlabel('\nTotal Salary ($)', fontsize = 9.5)
plt.ylabel('')
plt.show()
```


    
![png](output_124_0.png)
    


#####
6. What is the average salary by recruitment source?


```python
a = pd.DataFrame(df.groupby('recruitmentsource')['salary'].mean().sort_values(ascending = False))
a.columns = ['Average Salary']
a
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Average Salary</th>
    </tr>
    <tr>
      <th>recruitmentsource</th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>Other</th>
      <td>83263.500000</td>
    </tr>
    <tr>
      <th>Employee Referral</th>
      <td>77862.838710</td>
    </tr>
    <tr>
      <th>Indeed</th>
      <td>75495.747126</td>
    </tr>
    <tr>
      <th>Diversity Job Fair</th>
      <td>72251.241379</td>
    </tr>
    <tr>
      <th>LinkedIn</th>
      <td>64903.315789</td>
    </tr>
    <tr>
      <th>CareerBuilder</th>
      <td>63482.521739</td>
    </tr>
    <tr>
      <th>Website</th>
      <td>61537.692308</td>
    </tr>
    <tr>
      <th>Google Search</th>
      <td>60744.836735</td>
    </tr>
    <tr>
      <th>On-line Web application</th>
      <td>52505.000000</td>
    </tr>
  </tbody>
</table>
</div>



#####
7. What is the average salary grouped by performance score?


```python
a = pd.DataFrame(df.groupby('performancescore')['salary'].mean().sort_values(ascending = False))
a.plot(kind = 'barh', edgecolor = 'black', color = ['skyblue', 'gold', 'tomato', 'teal', 'navy', 'peachpuff','red'], figsize = (17, 6))
plt.title('\nAverage Salary Cost By Performance Score\n', fontsize = 11)
plt.xlabel('\nPerforance Rating', fontsize = 9.5)
plt.ylabel('')
plt.show()
```


    
![png](output_128_0.png)
    


#####
8. How does salary vary by race description?


```python
a = pd.DataFrame(df.groupby('racedesc')['salary'].mean().sort_values(ascending = False))
a.columns = ['Average Salary']
a
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Average Salary</th>
    </tr>
    <tr>
      <th>racedesc</th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>Hispanic</th>
      <td>83667.000000</td>
    </tr>
    <tr>
      <th>Black or African American</th>
      <td>74431.025000</td>
    </tr>
    <tr>
      <th>Asian</th>
      <td>68521.206897</td>
    </tr>
    <tr>
      <th>White</th>
      <td>67287.545455</td>
    </tr>
    <tr>
      <th>American Indian or Alaska Native</th>
      <td>65806.000000</td>
    </tr>
    <tr>
      <th>Two or more races</th>
      <td>59998.181818</td>
    </tr>
  </tbody>
</table>
</div>



#####
9. What is the average salary of employees grouped by sex?


```python
a = pd.DataFrame(df.groupby('sex')['salary'].mean().sort_values(ascending = False))
a.columns = ['Average Salary']
a
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Average Salary</th>
    </tr>
    <tr>
      <th>sex</th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>M</th>
      <td>70629.400000</td>
    </tr>
    <tr>
      <th>F</th>
      <td>67786.727273</td>
    </tr>
  </tbody>
</table>
</div>



#####
10. What is the total salary grouped by manager name?


```python
a = pd.DataFrame(df.groupby('managername')['salary'].mean().sort_values(ascending = False))
a.columns = ['Average Salary']
a
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Average Salary</th>
    </tr>
    <tr>
      <th>managername</th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>Board of Directors</th>
      <td>174675.500000</td>
    </tr>
    <tr>
      <th>Jennifer Zamora</th>
      <td>136061.142857</td>
    </tr>
    <tr>
      <th>Simon Roup</th>
      <td>99331.411765</td>
    </tr>
    <tr>
      <th>Brian Champaigne</th>
      <td>98319.750000</td>
    </tr>
    <tr>
      <th>Alex Sweetwater</th>
      <td>98203.222222</td>
    </tr>
    <tr>
      <th>Janet King</th>
      <td>94814.842105</td>
    </tr>
    <tr>
      <th>Peter Monroe</th>
      <td>73578.500000</td>
    </tr>
    <tr>
      <th>Debra Houlihan</th>
      <td>69240.000000</td>
    </tr>
    <tr>
      <th>John Smith</th>
      <td>65350.428571</td>
    </tr>
    <tr>
      <th>Brandon R. LeBlanc</th>
      <td>64818.571429</td>
    </tr>
    <tr>
      <th>Lynn Daneault</th>
      <td>64482.538462</td>
    </tr>
    <tr>
      <th>Eric Dougall</th>
      <td>63188.750000</td>
    </tr>
    <tr>
      <th>Elijiah Gray</th>
      <td>60635.954545</td>
    </tr>
    <tr>
      <th>Brannon Miller</th>
      <td>60095.454545</td>
    </tr>
    <tr>
      <th>Kelley Spirea</th>
      <td>58912.181818</td>
    </tr>
    <tr>
      <th>Michael Albert</th>
      <td>58343.636364</td>
    </tr>
    <tr>
      <th>Amy Dunn</th>
      <td>57881.857143</td>
    </tr>
    <tr>
      <th>Webster Butler</th>
      <td>57381.238095</td>
    </tr>
    <tr>
      <th>Kissy Sullivan</th>
      <td>57183.818182</td>
    </tr>
    <tr>
      <th>David Stanley</th>
      <td>56938.571429</td>
    </tr>
    <tr>
      <th>Ketsia Liebig</th>
      <td>56936.666667</td>
    </tr>
  </tbody>
</table>
</div>



#####
11. What is the average salary of employees with more than 5 years at the company?


```python
five_slr = df[(df['hire_year'] < 2014) & (pd.isna(df['termination_year']))]
five_slr['salary'].mean()
```




    69834.70192307692



#####
12. What is the salary distribution by marital status?


```python
a = pd.DataFrame(df.groupby('maritaldesc')['salary'].mean().sort_values(ascending = False))
a.columns = ['Average Salary']
a
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Average Salary</th>
    </tr>
    <tr>
      <th>maritaldesc</th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>Single</th>
      <td>70052.576642</td>
    </tr>
    <tr>
      <th>Married</th>
      <td>69827.717742</td>
    </tr>
    <tr>
      <th>Widowed</th>
      <td>65195.125000</td>
    </tr>
    <tr>
      <th>Divorced</th>
      <td>64427.333333</td>
    </tr>
    <tr>
      <th>Separated</th>
      <td>62934.333333</td>
    </tr>
  </tbody>
</table>
</div>



#####
13. What is the average salary grouped by termination reason?


```python
a = pd.DataFrame(df.groupby('termreason')['salary'].mean().sort_values(ascending = False))
a.columns = ['Average Salary']
a
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Average Salary</th>
    </tr>
    <tr>
      <th>termreason</th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>Learned that he is a gangster</th>
      <td>103613.000000</td>
    </tr>
    <tr>
      <th>no-call, no-show</th>
      <td>84460.750000</td>
    </tr>
    <tr>
      <th>performance</th>
      <td>78727.750000</td>
    </tr>
    <tr>
      <th>hours</th>
      <td>75731.625000</td>
    </tr>
    <tr>
      <th>medical issues</th>
      <td>73898.333333</td>
    </tr>
    <tr>
      <th>N/A-StillEmployed</th>
      <td>70694.033816</td>
    </tr>
    <tr>
      <th>Fatal attraction</th>
      <td>70187.000000</td>
    </tr>
    <tr>
      <th>attendance</th>
      <td>67347.428571</td>
    </tr>
    <tr>
      <th>Another position</th>
      <td>66116.900000</td>
    </tr>
    <tr>
      <th>career change</th>
      <td>65409.444444</td>
    </tr>
    <tr>
      <th>maternity leave - did not return</th>
      <td>63800.000000</td>
    </tr>
    <tr>
      <th>unhappy</th>
      <td>61348.928571</td>
    </tr>
    <tr>
      <th>relocation out of area</th>
      <td>61225.400000</td>
    </tr>
    <tr>
      <th>retiring</th>
      <td>60527.750000</td>
    </tr>
    <tr>
      <th>military</th>
      <td>59981.750000</td>
    </tr>
    <tr>
      <th>more money</th>
      <td>57148.454545</td>
    </tr>
    <tr>
      <th>return to school</th>
      <td>55671.000000</td>
    </tr>
    <tr>
      <th>gross misconduct</th>
      <td>49773.000000</td>
    </tr>
  </tbody>
</table>
</div>



#####
14. How does the average salary vary for employees hired in each year?


```python
a = pd.DataFrame(df.groupby('hire_year')['salary'].mean().sort_values(ascending = False))
a.columns = ['Average Salary']
a
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Average Salary</th>
    </tr>
    <tr>
      <th>hire_year</th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>2017</th>
      <td>101509.000000</td>
    </tr>
    <tr>
      <th>2010</th>
      <td>81972.555556</td>
    </tr>
    <tr>
      <th>2009</th>
      <td>78918.571429</td>
    </tr>
    <tr>
      <th>2016</th>
      <td>75795.285714</td>
    </tr>
    <tr>
      <th>2015</th>
      <td>75082.111111</td>
    </tr>
    <tr>
      <th>2012</th>
      <td>69296.066667</td>
    </tr>
    <tr>
      <th>2014</th>
      <td>69262.433333</td>
    </tr>
    <tr>
      <th>2013</th>
      <td>65400.909091</td>
    </tr>
    <tr>
      <th>2006</th>
      <td>64397.000000</td>
    </tr>
    <tr>
      <th>2011</th>
      <td>63112.385542</td>
    </tr>
    <tr>
      <th>2008</th>
      <td>58834.666667</td>
    </tr>
    <tr>
      <th>2007</th>
      <td>57088.500000</td>
    </tr>
    <tr>
      <th>2018</th>
      <td>56991.000000</td>
    </tr>
  </tbody>
</table>
</div>



#####
15. How does salary vary by the number of special projects?


```python
a = pd.DataFrame(df.groupby('specialprojectscount')['salary'].mean().sort_values(ascending = False))
a.columns = ['Average Salary']
a
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Average Salary</th>
    </tr>
    <tr>
      <th>specialprojectscount</th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>2</th>
      <td>99351.000000</td>
    </tr>
    <tr>
      <th>7</th>
      <td>98738.000000</td>
    </tr>
    <tr>
      <th>8</th>
      <td>96127.000000</td>
    </tr>
    <tr>
      <th>6</th>
      <td>93252.380952</td>
    </tr>
    <tr>
      <th>5</th>
      <td>92386.000000</td>
    </tr>
    <tr>
      <th>3</th>
      <td>90781.666667</td>
    </tr>
    <tr>
      <th>4</th>
      <td>86401.444444</td>
    </tr>
    <tr>
      <th>1</th>
      <td>64021.000000</td>
    </tr>
    <tr>
      <th>0</th>
      <td>62143.514523</td>
    </tr>
  </tbody>
</table>
</div>



#####
16. What is the average salary for employees with no absences in the last 30 days?


```python
df3874 = df[df['dayslatelast30'] == 0]
df3874['salary'].mean()
```




    69534.13309352518



#####
17. What is the median salary for each hire month?


```python
a = pd.DataFrame(df.groupby('hire_month')['salary'].mean().sort_values(ascending = False))
a.columns = ['Average Salary']
a
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Average Salary</th>
    </tr>
    <tr>
      <th>hire_month</th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>December</th>
      <td>93093.000000</td>
    </tr>
    <tr>
      <th>February</th>
      <td>75306.032258</td>
    </tr>
    <tr>
      <th>January</th>
      <td>74859.759259</td>
    </tr>
    <tr>
      <th>June</th>
      <td>72930.375000</td>
    </tr>
    <tr>
      <th>October</th>
      <td>72797.285714</td>
    </tr>
    <tr>
      <th>April</th>
      <td>71874.185185</td>
    </tr>
    <tr>
      <th>November</th>
      <td>70027.714286</td>
    </tr>
    <tr>
      <th>March</th>
      <td>69666.210526</td>
    </tr>
    <tr>
      <th>July</th>
      <td>65476.250000</td>
    </tr>
    <tr>
      <th>May</th>
      <td>65454.333333</td>
    </tr>
    <tr>
      <th>August</th>
      <td>64141.700000</td>
    </tr>
    <tr>
      <th>September</th>
      <td>60348.282051</td>
    </tr>
  </tbody>
</table>
</div>



## Demographics Analysis

#####
1. What is the count of employees grouped by race and gender?


```python
a = df.groupby(['sex', 'racedesc'])['sex'].count().sort_values(ascending = False).unstack()
a.plot(kind = 'bar', stacked = True, edgecolor = 'black', figsize = (18,8))
plt.title('\nEmployee Gender And Race Distribution\n', fontsize = 11)
plt.xlabel('\nGender', fontsize = 9.5)
plt.xticks(rotation = 0)
plt.ylabel('Count', fontsize = 9.5)
plt.legend(loc = 'center', edgecolor = 'black', title = 'Races')
plt.show()
```


    
![png](output_151_0.png)
    


#####
2. What is the average age of employees in each department?


```python
df_mar = df[df['birth_year'] < 2005]
df_mar['age'] = 2024 - df_mar['birth_year']
a = pd.DataFrame(df_mar.groupby('department')['age'].mean().sort_values(ascending = False))
a.columns = ['Average Age']
a
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Average Age</th>
    </tr>
    <tr>
      <th>department</th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>Production</th>
      <td>43.178218</td>
    </tr>
    <tr>
      <th>IT/IS</th>
      <td>42.550000</td>
    </tr>
    <tr>
      <th>Software Engineering</th>
      <td>41.200000</td>
    </tr>
    <tr>
      <th>Admin Offices</th>
      <td>39.000000</td>
    </tr>
    <tr>
      <th>Sales</th>
      <td>38.666667</td>
    </tr>
  </tbody>
</table>
</div>



#####
3. How does the average age vary by marital status?


```python
df_mar = df[df['birth_year'] < 2005]
df_mar['age'] = 2024 - df_mar['birth_year']
a = pd.DataFrame(df_mar.groupby('maritaldesc')['age'].mean().sort_values(ascending = False))
a.columns = ['Average Age']
a
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Average Age</th>
    </tr>
    <tr>
      <th>maritaldesc</th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>Divorced</th>
      <td>44.611111</td>
    </tr>
    <tr>
      <th>Widowed</th>
      <td>44.600000</td>
    </tr>
    <tr>
      <th>Single</th>
      <td>42.758065</td>
    </tr>
    <tr>
      <th>Separated</th>
      <td>42.250000</td>
    </tr>
    <tr>
      <th>Married</th>
      <td>41.272727</td>
    </tr>
  </tbody>
</table>
</div>



#####
4. How does employee satisfaction vary by sex and race?


```python
a = pd.DataFrame(df.groupby(['racedesc', 'sex'])['empsatisfaction'].mean().sort_values(ascending = False).unstack())
a.plot(kind = 'bar',edgecolor = 'black', stacked = True, figsize = (18,8))
plt.title('\nEmployee Satisfaction By Race And Gender\n', fontsize = 11)
plt.xlabel('\nRace', fontsize = 9.5)
plt.xticks(rotation = 0)
plt.ylabel('Count', fontsize = 9.5)
plt.legend(loc = 'upper center', edgecolor = 'black', title = 'Gender')
plt.show()
```


    
![png](output_157_0.png)
    


#####
5. What is the most common race for each department?


```python
a = pd.DataFrame(df.groupby(['department', 'racedesc'])['racedesc'].count().sort_values(ascending = False).unstack())
a.plot(kind = 'bar',edgecolor = 'black', stacked = True, figsize = (18,10))
plt.title('\nDepartment Distribution By Race\n', fontsize = 11)
plt.xlabel('\nDepartment', fontsize = 9.5)
plt.xticks(rotation = 0)
plt.ylabel('Number Of Employees', fontsize = 9.5)
plt.legend(loc = 'upper left', edgecolor = 'black', title = 'Race')
plt.show()
```


    
![png](output_159_0.png)
    


#####
6.   What is the engagement survey score grouped by marital status?


```python
df_mar = df[df['birth_year'] < 2005]
a = pd.DataFrame(df_mar.groupby('maritaldesc')['engagementsurvey'].mean().sort_values(ascending = False))
a.columns = ['Average Age']
a
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Average Age</th>
    </tr>
    <tr>
      <th>maritaldesc</th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>Widowed</th>
      <td>4.370000</td>
    </tr>
    <tr>
      <th>Divorced</th>
      <td>4.193333</td>
    </tr>
    <tr>
      <th>Single</th>
      <td>4.185161</td>
    </tr>
    <tr>
      <th>Married</th>
      <td>3.967636</td>
    </tr>
    <tr>
      <th>Separated</th>
      <td>3.910000</td>
    </tr>
  </tbody>
</table>
</div>



#####
7. What is the average satisfaction grouped by department and sex?


```python
a = pd.DataFrame(df.groupby(['department', 'sex'])['empsatisfaction'].mean().sort_values(ascending = False).unstack())
a.plot(kind = 'bar',edgecolor = 'black', stacked = True, figsize = (18,10), color = ['deeppink', 'teal'])
plt.title('\nEmployee Satisfaction Score By Department And Sex\n', fontsize = 11)
plt.xlabel('\nDepartment', fontsize = 9.5)
plt.xticks(rotation = 0)
plt.ylabel('Average Employee Rating', fontsize = 9.5)
plt.legend(loc = 'upper left', edgecolor = 'black', title = 'Race')
plt.show()
```


    
![png](output_163_0.png)
    


#####
8. How many employees are Hispanic/Latino in each department?


```python
df_lat = df[df['racedesc'] == 'Hispanic']
plt.figure(figsize = (17, 5))
df['department'].value_counts().plot(kind = 'bar', edgecolor = 'black', color = ['gold', 'deeppink', 'darkorchid', 'teal', 'orange'])
plt.title('\nHispanic/Latino Distribution By Department\n', fontsize = 11)
plt.xlabel('\nDepartment', fontsize = 11)
plt.xticks(rotation = 0)
plt.ylabel('Count of Employees in Department', fontsize = 9.5)
plt.show()
```


    
![png](output_165_0.png)
    


#####
9.  What is the average birth year grouped by marital status?


```python
df_mar = df[df['birth_year'] < 2005]
a = pd.DataFrame(df_mar.groupby('maritaldesc')['birth_year'].mean().sort_values(ascending = False))
a.columns = ['Average Birth Year']
a
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Average Birth Year</th>
    </tr>
    <tr>
      <th>maritaldesc</th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>Married</th>
      <td>1982.727273</td>
    </tr>
    <tr>
      <th>Separated</th>
      <td>1981.750000</td>
    </tr>
    <tr>
      <th>Single</th>
      <td>1981.241935</td>
    </tr>
    <tr>
      <th>Widowed</th>
      <td>1979.400000</td>
    </tr>
    <tr>
      <th>Divorced</th>
      <td>1979.388889</td>
    </tr>
  </tbody>
</table>
</div>



#####
10. How many employees of each **gender** and **race** were terminated for poor performance?


```python
df_ter = df[df['termreason'] == 'performance']
ge_dist = df_ter['sex'].value_counts()
rc_dist = df['racedesc'].value_counts()

plt.figure(figsize = (27,27))
plt.subplot(1,2,1)
ge_dist.plot(kind = 'pie', autopct = '%1.1f%%')
plt.title('Gender Distribution (Poor Performance)', fontsize = 17)
plt.xlabel('')
plt.ylabel('')

plt.subplot(1,2,2)
rc_dist.plot(kind = 'pie', autopct = '%1.1f%%')
plt.title('Race Distribution (Poor Performance)', fontsize = 17)
plt.xlabel('')
plt.ylabel('')
plt.subplots_adjust(wspace = 0.5)
plt.show()
```


    
![png](output_169_0.png)
    


#####
11. How many employees of each **gender** and **race** left for another position?


```python
df_ter = df[df['termreason'] == 'Another position']
ge_dist = df_ter['sex'].value_counts()
rc_dist = df['racedesc'].value_counts()

plt.figure(figsize = (27,27))
plt.subplot(1,2,1)
ge_dist.plot(kind = 'pie', autopct = '%1.1f%%')
plt.title('Gender Distribution', fontsize = 17)
plt.xlabel('')
plt.ylabel('')

plt.subplot(1,2,2)
rc_dist.plot(kind = 'pie', autopct = '%1.1f%%')
plt.title('Race Distribution', fontsize = 17)
plt.xlabel('')
plt.ylabel('')
plt.subplots_adjust(wspace = 0.5)
plt.show()
```


    
![png](output_171_0.png)
    


#####
12. How many employees of each **gender** and **race** left for a career change?


```python
df_ter = df[df['termreason'] == 'career change']
ge_dist = df_ter['sex'].value_counts()
rc_dist = df['racedesc'].value_counts()

plt.figure(figsize = (27,27))
plt.subplot(1,2,1)
ge_dist.plot(kind = 'pie', autopct = '%1.1f%%')
plt.title('Gender Distribution', fontsize = 17)
plt.xlabel('')
plt.ylabel('')

plt.subplot(1,2,2)
rc_dist.plot(kind = 'pie', autopct = '%1.1f%%')
plt.title('Race Distribution', fontsize = 17)
plt.xlabel('')
plt.ylabel('')
plt.subplots_adjust(wspace = 0.5)
plt.show()
```


    
![png](output_173_0.png)
    


#####
13. How many employees of each **gender** and **race** left because of medical issues?


```python
df_ter = df[df['termreason'] == 'medical issues']
ge_dist = df_ter['sex'].value_counts()
rc_dist = df['racedesc'].value_counts()

plt.figure(figsize = (27,27))
plt.subplot(1,2,1)
ge_dist.plot(kind = 'pie', autopct = '%1.1f%%')
plt.title('Gender Distribution', fontsize = 17)
plt.xlabel('')
plt.ylabel('')

plt.subplot(1,2,2)
rc_dist.plot(kind = 'pie', autopct = '%1.1f%%')
plt.title('Race Distribution', fontsize = 17)
plt.xlabel('')
plt.ylabel('')
plt.subplots_adjust(wspace = 0.5)
plt.show()
```


    
![png](output_175_0.png)
    


#####
14. How many employees of each **gender** and **race** were fired for gross misconduct?


```python
df_ter = df[df['termreason'] == 'gross misconduct']
ge_dist = df_ter['sex'].value_counts()
rc_dist = df['racedesc'].value_counts()

plt.figure(figsize = (27,27))
plt.subplot(1,2,1)
ge_dist.plot(kind = 'pie', autopct = '%1.1f%%')
plt.title('Gender Distribution', fontsize = 17)
plt.xlabel('')
plt.ylabel('')

plt.subplot(1,2,2)
rc_dist.plot(kind = 'pie', autopct = '%1.1f%%')
plt.title('Race Distribution', fontsize = 17)
plt.xlabel('')
plt.ylabel('')
plt.subplots_adjust(wspace = 0.5)
plt.show()
```


    
![png](output_177_0.png)
    


#####
15. How many employees of each **gender** and **race** left because they retired?


```python
df_ter = df[df['termreason'] == 'retiring']
ge_dist = df_ter['sex'].value_counts()
rc_dist = df['racedesc'].value_counts()

plt.figure(figsize = (27,27))
plt.subplot(1,2,1)
ge_dist.plot(kind = 'pie', autopct = '%1.1f%%')
plt.title('Gender Distribution', fontsize = 17)
plt.xlabel('')
plt.ylabel('')

plt.subplot(1,2,2)
rc_dist.plot(kind = 'pie', autopct = '%1.1f%%')
plt.title('Race Distribution', fontsize = 17)
plt.xlabel('')
plt.ylabel('')
plt.subplots_adjust(wspace = 0.5)
plt.show()
```


    
![png](output_179_0.png)
    


## Recruitment Analysis

#####
1. What is the average salary of employees hired through each recruitment source?


```python
df_mar = df[df['birth_year'] < 2005]
df_mar['age'] = 2024 - df_mar['birth_year']
a = pd.DataFrame(df_mar.groupby('recruitmentsource')['age'].mean().sort_values(ascending = False))
a.columns = ['Average Age']
a
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Average Age</th>
    </tr>
    <tr>
      <th>recruitmentsource</th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>Diversity Job Fair</th>
      <td>47.272727</td>
    </tr>
    <tr>
      <th>On-line Web application</th>
      <td>47.000000</td>
    </tr>
    <tr>
      <th>Other</th>
      <td>47.000000</td>
    </tr>
    <tr>
      <th>Google Search</th>
      <td>44.157895</td>
    </tr>
    <tr>
      <th>Employee Referral</th>
      <td>42.461538</td>
    </tr>
    <tr>
      <th>LinkedIn</th>
      <td>42.000000</td>
    </tr>
    <tr>
      <th>CareerBuilder</th>
      <td>41.700000</td>
    </tr>
    <tr>
      <th>Indeed</th>
      <td>41.272727</td>
    </tr>
    <tr>
      <th>Website</th>
      <td>39.875000</td>
    </tr>
  </tbody>
</table>
</div>



#####
2. What is the engagement survey score grouped by recruitment source?


```python
a = pd.DataFrame(df_mar.groupby('recruitmentsource')['engagementsurvey'].mean().sort_values(ascending = False))
a.columns = ['Average Rating']
a
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Average Rating</th>
    </tr>
    <tr>
      <th>recruitmentsource</th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>On-line Web application</th>
      <td>5.000000</td>
    </tr>
    <tr>
      <th>Other</th>
      <td>4.550000</td>
    </tr>
    <tr>
      <th>Website</th>
      <td>4.391250</td>
    </tr>
    <tr>
      <th>Employee Referral</th>
      <td>4.381538</td>
    </tr>
    <tr>
      <th>Diversity Job Fair</th>
      <td>4.126364</td>
    </tr>
    <tr>
      <th>Google Search</th>
      <td>4.123684</td>
    </tr>
    <tr>
      <th>CareerBuilder</th>
      <td>4.119000</td>
    </tr>
    <tr>
      <th>LinkedIn</th>
      <td>4.043611</td>
    </tr>
    <tr>
      <th>Indeed</th>
      <td>3.954091</td>
    </tr>
  </tbody>
</table>
</div>



#####
3. How many employees were hired in each department for each hire month?


```python
pd.DataFrame(df.groupby(['department', 'hire_month'])['hire_month'].count())
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th></th>
      <th>hire_month</th>
    </tr>
    <tr>
      <th>department</th>
      <th>hire_month</th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th rowspan="5" valign="top">Admin Offices</th>
      <th>February</th>
      <td>2</td>
    </tr>
    <tr>
      <th>January</th>
      <td>3</td>
    </tr>
    <tr>
      <th>May</th>
      <td>1</td>
    </tr>
    <tr>
      <th>October</th>
      <td>1</td>
    </tr>
    <tr>
      <th>September</th>
      <td>2</td>
    </tr>
    <tr>
      <th>Executive Office</th>
      <th>July</th>
      <td>1</td>
    </tr>
    <tr>
      <th rowspan="11" valign="top">IT/IS</th>
      <th>April</th>
      <td>4</td>
    </tr>
    <tr>
      <th>December</th>
      <td>1</td>
    </tr>
    <tr>
      <th>February</th>
      <td>9</td>
    </tr>
    <tr>
      <th>January</th>
      <td>13</td>
    </tr>
    <tr>
      <th>July</th>
      <td>1</td>
    </tr>
    <tr>
      <th>June</th>
      <td>3</td>
    </tr>
    <tr>
      <th>March</th>
      <td>8</td>
    </tr>
    <tr>
      <th>May</th>
      <td>1</td>
    </tr>
    <tr>
      <th>November</th>
      <td>5</td>
    </tr>
    <tr>
      <th>October</th>
      <td>2</td>
    </tr>
    <tr>
      <th>September</th>
      <td>3</td>
    </tr>
    <tr>
      <th rowspan="11" valign="top">Production</th>
      <th>April</th>
      <td>22</td>
    </tr>
    <tr>
      <th>August</th>
      <td>15</td>
    </tr>
    <tr>
      <th>February</th>
      <td>16</td>
    </tr>
    <tr>
      <th>January</th>
      <td>33</td>
    </tr>
    <tr>
      <th>July</th>
      <td>37</td>
    </tr>
    <tr>
      <th>June</th>
      <td>5</td>
    </tr>
    <tr>
      <th>March</th>
      <td>8</td>
    </tr>
    <tr>
      <th>May</th>
      <td>24</td>
    </tr>
    <tr>
      <th>November</th>
      <td>17</td>
    </tr>
    <tr>
      <th>October</th>
      <td>4</td>
    </tr>
    <tr>
      <th>September</th>
      <td>28</td>
    </tr>
    <tr>
      <th rowspan="9" valign="top">Sales</th>
      <th>April</th>
      <td>1</td>
    </tr>
    <tr>
      <th>August</th>
      <td>4</td>
    </tr>
    <tr>
      <th>February</th>
      <td>2</td>
    </tr>
    <tr>
      <th>January</th>
      <td>4</td>
    </tr>
    <tr>
      <th>July</th>
      <td>4</td>
    </tr>
    <tr>
      <th>March</th>
      <td>3</td>
    </tr>
    <tr>
      <th>May</th>
      <td>6</td>
    </tr>
    <tr>
      <th>November</th>
      <td>1</td>
    </tr>
    <tr>
      <th>September</th>
      <td>6</td>
    </tr>
    <tr>
      <th rowspan="6" valign="top">Software Engineering</th>
      <th>August</th>
      <td>1</td>
    </tr>
    <tr>
      <th>February</th>
      <td>2</td>
    </tr>
    <tr>
      <th>January</th>
      <td>1</td>
    </tr>
    <tr>
      <th>July</th>
      <td>1</td>
    </tr>
    <tr>
      <th>May</th>
      <td>1</td>
    </tr>
    <tr>
      <th>November</th>
      <td>5</td>
    </tr>
  </tbody>
</table>
</div>



## Feature Engineering


```python
df.columns
```




    Index(['employee_name', 'empid', 'marriedid', 'maritalstatusid', 'genderid',
           'empstatusid', 'deptid', 'perfscoreid', 'fromdiversityjobfairid',
           'salary', 'termd', 'positionid', 'position', 'state', 'zip', 'dob',
           'sex', 'maritaldesc', 'citizendesc', 'hispaniclatino', 'racedesc',
           'dateofhire', 'dateoftermination', 'termreason', 'employmentstatus',
           'department', 'managername', 'managerid', 'recruitmentsource',
           'performancescore', 'engagementsurvey', 'empsatisfaction',
           'specialprojectscount', 'lastperformancereview_date', 'dayslatelast30',
           'absences', 'hire_year', 'termination_year', 'hire_month',
           'termination_month', 'hire_day', 'termination_day', 'birth_year',
           'birth_month', 'birth_day'],
          dtype='object')



*creating copy of the dataset*


```python
d2 = df[['salary','position', 'state', 'sex', 'maritaldesc', 'citizendesc', 'racedesc', 'hire_year', 'department', 'managername',
         'recruitmentsource', 'specialprojectscount', 'empsatisfaction', 'performancescore']]
d2.head(4)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>salary</th>
      <th>position</th>
      <th>state</th>
      <th>sex</th>
      <th>maritaldesc</th>
      <th>citizendesc</th>
      <th>racedesc</th>
      <th>hire_year</th>
      <th>department</th>
      <th>managername</th>
      <th>recruitmentsource</th>
      <th>specialprojectscount</th>
      <th>empsatisfaction</th>
      <th>performancescore</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>62506</td>
      <td>Production Technician I</td>
      <td>MA</td>
      <td>M</td>
      <td>Single</td>
      <td>US Citizen</td>
      <td>White</td>
      <td>2011</td>
      <td>Production</td>
      <td>Michael Albert</td>
      <td>LinkedIn</td>
      <td>0</td>
      <td>5</td>
      <td>Exceeds</td>
    </tr>
    <tr>
      <th>1</th>
      <td>104437</td>
      <td>Sr. DBA</td>
      <td>MA</td>
      <td>M</td>
      <td>Married</td>
      <td>US Citizen</td>
      <td>White</td>
      <td>2015</td>
      <td>IT/IS</td>
      <td>Simon Roup</td>
      <td>Indeed</td>
      <td>6</td>
      <td>3</td>
      <td>Fully Meets</td>
    </tr>
    <tr>
      <th>2</th>
      <td>64955</td>
      <td>Production Technician II</td>
      <td>MA</td>
      <td>F</td>
      <td>Married</td>
      <td>US Citizen</td>
      <td>White</td>
      <td>2011</td>
      <td>Production</td>
      <td>Kissy Sullivan</td>
      <td>LinkedIn</td>
      <td>0</td>
      <td>3</td>
      <td>Fully Meets</td>
    </tr>
    <tr>
      <th>3</th>
      <td>64991</td>
      <td>Production Technician I</td>
      <td>MA</td>
      <td>F</td>
      <td>Married</td>
      <td>US Citizen</td>
      <td>White</td>
      <td>2008</td>
      <td>Production</td>
      <td>Elijiah Gray</td>
      <td>Indeed</td>
      <td>0</td>
      <td>5</td>
      <td>Fully Meets</td>
    </tr>
  </tbody>
</table>
</div>




```python
len(d2.columns)
```




    14



*label encoding features*


```python
from sklearn.preprocessing import LabelEncoder
e = LabelEncoder()
d2['position'] = e.fit_transform(d2['position'])
d2['state'] = e.fit_transform(d2['state'])
d2['sex'] = e.fit_transform(d2['sex'])
d2['maritaldesc'] = e.fit_transform(d2['maritaldesc'])
d2['citizendesc'] = e.fit_transform(d2['citizendesc'])
d2['racedesc'] = e.fit_transform(d2['racedesc'])
d2['department'] = e.fit_transform(d2['department'])
d2['managername'] = e.fit_transform(d2['managername'])
d2['recruitmentsource'] = e.fit_transform(d2['recruitmentsource'])
d2['performancescore'] = e.fit_transform(d2['performancescore'])
```

*verifying encoding*


```python
d2.head(4)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>salary</th>
      <th>position</th>
      <th>state</th>
      <th>sex</th>
      <th>maritaldesc</th>
      <th>citizendesc</th>
      <th>racedesc</th>
      <th>hire_year</th>
      <th>department</th>
      <th>managername</th>
      <th>recruitmentsource</th>
      <th>specialprojectscount</th>
      <th>empsatisfaction</th>
      <th>performancescore</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>62506</td>
      <td>22</td>
      <td>10</td>
      <td>1</td>
      <td>3</td>
      <td>2</td>
      <td>5</td>
      <td>2011</td>
      <td>3</td>
      <td>17</td>
      <td>5</td>
      <td>0</td>
      <td>5</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>104437</td>
      <td>30</td>
      <td>10</td>
      <td>1</td>
      <td>1</td>
      <td>2</td>
      <td>5</td>
      <td>2015</td>
      <td>2</td>
      <td>19</td>
      <td>4</td>
      <td>6</td>
      <td>3</td>
      <td>1</td>
    </tr>
    <tr>
      <th>2</th>
      <td>64955</td>
      <td>23</td>
      <td>10</td>
      <td>0</td>
      <td>1</td>
      <td>2</td>
      <td>5</td>
      <td>2011</td>
      <td>3</td>
      <td>15</td>
      <td>5</td>
      <td>0</td>
      <td>3</td>
      <td>1</td>
    </tr>
    <tr>
      <th>3</th>
      <td>64991</td>
      <td>22</td>
      <td>10</td>
      <td>0</td>
      <td>1</td>
      <td>2</td>
      <td>5</td>
      <td>2008</td>
      <td>3</td>
      <td>8</td>
      <td>4</td>
      <td>0</td>
      <td>5</td>
      <td>1</td>
    </tr>
  </tbody>
</table>
</div>



*split data into x and y*


```python
x = d2.drop(columns = ['performancescore'])
y = d2['performancescore']
```

#### *selecting best x feaatures*


```python
from sklearn.feature_selection import SelectKBest, chi2, f_classif
selector = SelectKBest(score_func = chi2, k = 4)
x_new = selector.fit_transform(x, y)

# Get the boolean mask of selected features
selected_mask = selector.get_support()

# Get the column names of the selected features
selected_columns = x.columns[selected_mask]

print("Selected Features:")
print(selected_columns)

```

    Selected Features:
    Index(['salary', 'position', 'managername', 'specialprojectscount'], dtype='object')


*split data into train and test*


```python
from sklearn.model_selection import train_test_split as t
x_train, x_test, y_train, y_test = t(x_new, y, test_size = 0.2, random_state = 1)
```

#### *scaling x values*


```python
from sklearn.preprocessing import StandardScaler
s = StandardScaler()
x_train_scaled = s.fit_transform(x_train)
x_test_scaled = s.fit_transform(x_test)
```

#### *function to evaluate models*


```python
from sklearn.metrics import accuracy_score, f1_score
def evaluator(pred):
    print(f"accuracy score: {accuracy_score(y_test, pred)}")
    print(f"f1 score: {f1_score(y_test, pred, average = 'weighted')}")
```

###
#### *Training and Evaluating Models*
###

*first model: **logistic regression***


```python
from sklearn.linear_model import LogisticRegression
l = LogisticRegression()

# training model
l.fit(x_train_scaled, y_train)

# creating predictor
lp = l.predict(x_test_scaled)

# evaluating model
evaluator(lp)
```

    accuracy score: 0.746031746031746
    f1 score: 0.6375180375180375


*second model: **kneighbor classifier***


```python
from sklearn.neighbors import KNeighborsClassifier
from sklearn.model_selection import GridSearchCV

# hyperparameters
p1 = {
    'n_neighbors':[4, 5, 10, 12],
    'weights':['uniform', 'distance', None],
    'leaf_size': [10, 20, 30, 40, 50],
    'n_jobs':[None, 2, 5]
}

# training model
k = GridSearchCV(KNeighborsClassifier(), param_grid = p1, cv = 5)
k.fit(x_train_scaled, y_train)

# creating predictor
kp = k.predict(x_test_scaled)

# evaluate model
evaluator(kp)
```

    accuracy score: 0.746031746031746
    f1 score: 0.6375180375180375



```python
# best parameters
k.best_params_
```




    {'leaf_size': 10, 'n_jobs': None, 'n_neighbors': 12, 'weights': 'uniform'}



*third model: **support vector classifier***


```python
from sklearn.svm import SVC

# hyperparameters
p2 = {
    'C': [0.1, 1, 10, 20],
    'kernel': ['linear', 'poly', 'rbf', 'sigmoid'], 
    'degree': [2, 3, 4, 10]
}

# train model
s = GridSearchCV(SVC(), param_grid = p2, cv = 5)
s.fit(x_train_scaled, y_train)

# create predictor
sp = s.predict(x_test_scaled)

# evaluate model
evaluator(sp)
```

    accuracy score: 0.746031746031746
    f1 score: 0.6609053497942388



```python
# best parameters
s.best_params_
```




    {'C': 1, 'degree': 3, 'kernel': 'poly'}



*fourth model: **random forest classifier***


```python
from sklearn.ensemble import RandomForestClassifier

# hyperparameters
p3 = {
    'n_estimators':[50, 100, 200, ],
    'min_samples_split':[2, 4, 6, 8, 10],
    'max_depth':[None, 5, 10, 15]
}

# train model
r = GridSearchCV(RandomForestClassifier(), param_grid = p3, cv = 3)
r.fit(x_train_scaled, y_train)

# create predictor
rp = r.predict(x_test_scaled)

# evaluate model
evaluator(rp)
```

    accuracy score: 0.746031746031746
    f1 score: 0.6375180375180375



```python
# best parameters
r.best_params_
```




    {'max_depth': 5, 'min_samples_split': 4, 'n_estimators': 50}



*fifth model: **xgboost classifier***


```python
from xgboost import XGBClassifier

# hyperparameters
p3 = {
    'n_estimators': [100, 200, 300, 500],
    'max_depth': [None, 5, 10], 
    'min_child_weight': [3, 5, 10], 
    'learning_rate': [0.01, 0.1, 1, 2],
}

# train model
xg = GridSearchCV(XGBClassifier(), param_grid = p3, cv = 5)
xg.fit(x_train_scaled, y_train)

# create predictor
xp = xg.predict(x_test_scaled)

# evaluate model
evaluator(xp)
```

    accuracy score: 0.746031746031746
    f1 score: 0.6375180375180375



```python
# best parameters
xg.best_params_
```




    {'learning_rate': 0.01,
     'max_depth': None,
     'min_child_weight': 5,
     'n_estimators': 100}



### predictions with best model


```python
pd.DataFrame(x_new).head(6)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>0</th>
      <th>1</th>
      <th>2</th>
      <th>3</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>62506</td>
      <td>22</td>
      <td>17</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>104437</td>
      <td>30</td>
      <td>19</td>
      <td>6</td>
    </tr>
    <tr>
      <th>2</th>
      <td>64955</td>
      <td>23</td>
      <td>15</td>
      <td>0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>64991</td>
      <td>22</td>
      <td>8</td>
      <td>0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>50825</td>
      <td>22</td>
      <td>20</td>
      <td>0</td>
    </tr>
    <tr>
      <th>5</th>
      <td>57568</td>
      <td>22</td>
      <td>1</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
</div>




```python
df[['salary', 'position', 'managername', 'specialprojectscount']].head(7)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>salary</th>
      <th>position</th>
      <th>managername</th>
      <th>specialprojectscount</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>62506</td>
      <td>Production Technician I</td>
      <td>Michael Albert</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>104437</td>
      <td>Sr. DBA</td>
      <td>Simon Roup</td>
      <td>6</td>
    </tr>
    <tr>
      <th>2</th>
      <td>64955</td>
      <td>Production Technician II</td>
      <td>Kissy Sullivan</td>
      <td>0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>64991</td>
      <td>Production Technician I</td>
      <td>Elijiah Gray</td>
      <td>0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>50825</td>
      <td>Production Technician I</td>
      <td>Webster Butler</td>
      <td>0</td>
    </tr>
    <tr>
      <th>5</th>
      <td>57568</td>
      <td>Production Technician I</td>
      <td>Amy Dunn</td>
      <td>0</td>
    </tr>
    <tr>
      <th>6</th>
      <td>95660</td>
      <td>Software Engineer</td>
      <td>Alex Sweetwater</td>
      <td>4</td>
    </tr>
  </tbody>
</table>
</div>




```python
new_employee = np.array([75000,22,17,4])
print('performance of a new employee from support vector model is {}'.format(s.predict(new_employee.reshape(1,-1))))
```

    performance of a new employee from support vector model is [0]


0 maps unto 'Exceeding Performance,' so a new employee who earns $75k, is a software engineer, managed by Michael Alber, and has 0 special projects will **exceed performance**
